package quiz.application;

import javax.swing.*;
import java.awt.*;

public class Score extends JFrame {

    Score(String name, int score, int totalQuestions, String[][] questions, String[] userAnswers,
            String[] correctAnswers) {
        setBounds(350, 150, 800, 600);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Thank you " + name + " for playing the Quiz");
        heading.setBounds(50, 0, 600, 30);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 24));
        add(heading);

        JLabel scoreLabel = new JLabel("Your Score: " + score + "/" + totalQuestions);
        scoreLabel.setBounds(50, 50, 300, 30);
        scoreLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(scoreLabel);

        JLabel percentageLabel = new JLabel("Percentage: "
                + (totalQuestions > 0 ? String.format("%.2f", (score * 100.0 / totalQuestions)) + "%" : "0%"));
        percentageLabel.setBounds(50, 80, 300, 30);
        percentageLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(percentageLabel);

        JLabel reviewLabel = new JLabel("Review your answers:");
        reviewLabel.setBounds(50, 110, 300, 30);
        reviewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(reviewLabel);

        JTextArea reviewArea = new JTextArea();
        for (int i = 0; i < questions.length; i++) {
            reviewArea.append("Q" + (i + 1) + ": " + questions[i][0] + "\n");
            reviewArea.append("Your Answer: "
                    + (userAnswers[i] != null && !userAnswers[i].isEmpty() ? userAnswers[i] : "No answer") + "\n");
            reviewArea.append("Correct Answer: " + correctAnswers[i] + "\n\n");
        }

        reviewArea.setEditable(false);
        reviewArea.setFont(new Font("Tahoma", Font.PLAIN, 16));

        JScrollPane scrollPane = new JScrollPane(reviewArea);
        scrollPane.setBounds(50, 150, 700, 350);
        add(scrollPane);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Score("User", 0, 0, new String[0][0], new String[0], new String[0]);
    }
}
